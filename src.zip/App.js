import React from "react";
import "./App.css";
import AppIndex from "./AppIndex";

export const StoreContext = React.createContext({});

function App() {
  const [loginUser, setLoginUser] = React.useState({});
  const getLoginUser = () => {
    const loginUserData = JSON.parse(localStorage.getItem("loginUser"));

    if (loginUserData) {
      setLoginUser({
        email: loginUserData.email,
        id: loginUserData.id,
      });
    }
  };

  React.useEffect(() => {
    getLoginUser();
  }, []);

  return (
    <StoreContext.Provider
      value={{
        loginUser,
        setLoginUser,
      }}
    >
      <AppIndex />
    </StoreContext.Provider>
  );
}

export default App;
