import React from "react";
import { Route, Routes, useNavigate } from "react-router-dom";
import axios from "axios";
import { StoreContext } from "./App";

axios.defaults.withCredentials = true;

function Login() {
  const navigation = useNavigate();

  const { setLoginUser } = React.useContext(StoreContext);
  const [user, setUser] = React.useState({
    email: "dureotkd123@naver.com",
    pw: "",
  });

  const 로그인처리 = async (event) => {
    event.preventDefault();

    await axios({
      url: "http://localhost:4000/login",
      params: user,
    })
      .then(({ data }) => {
        if (data.code === "fail") {
          alert(data.msg);
          return;
        }

        const user = data.user;
        localStorage.setItem("loginUser", JSON.stringify(user));
        setLoginUser({
          email: user.email,
          id: user.id,
        });
        navigation("/Main");
      })
      .catch((e) => {
        console.log(e);
      });
  };

  const 로그인정보입력 = (type, event) => {
    const cloneUser = { ...user };
    cloneUser[type] = event.target.value;
    setUser(cloneUser);
  };

  return (
    <form onSubmit={로그인처리} className="login-box">
      <img
        src={process.env.PUBLIC_URL + "/logo.gif"}
        alt="slack_logo"
        style={{ width: 200, marginBottom: 20 }}
      />
      <input
        type="email"
        name="email"
        placeholder="이메일"
        onChange={로그인정보입력.bind(this, "email")}
      />
      <input
        type="password"
        name="password"
        placeholder="비밀번호"
        onChange={로그인정보입력.bind(this, "pw")}
      />
      <button>로그인</button>
    </form>
  );
}

function Main() {
  const { loginUser } = React.useContext(StoreContext);
  const [myChatRoom, setMyChatRoom] = React.useState({});
  const [loading, setLoading] = React.useState(true);

  const 내가참여하고있는방데이터 = async () => {
    await axios({
      url: "http://localhost:4000/myJoinRoom",
    }).then(({ data }) => {
      setMyChatRoom(myChatRoom);
    });

    setLoading(false);
  };

  React.useEffect(() => {
    내가참여하고있는방데이터();
  }, []);

  if (loading) {
    return <div>로딩중..</div>;
  }

  return (
    <div>
      <div
        style={{
          height: "100vh",
          backgroundColor: "red",
          minWidth: 200,
          width: "15%",
          overflow: "scroll",
          overflowX: "hidden",
          overflowY: "hidden",
          background: "#3C4048",
        }}
      ></div>
    </div>
  );
}

function AppIndex() {
  return (
    <Routes>
      <Route exact path="/" element={<Login />} />
      <Route exact path="/Main" element={<Main />} />
    </Routes>
  );
}
export default AppIndex;
